import { Component } from '@angular/core';
import { Uporabnik } from './uporabnik';
import { Slika } from '../slika/slika';
import { SlikaComponent } from '../slika/slika.component';
import { UporabnikService } from './uporabnik.service';
import { SlikaService } from '../slika/slika.service';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'uporabnik',
  templateUrl:'./uporabnik.component.html',
  providers: [UporabnikService,SlikaService],
  styleUrls:['./uporabnik.component.css']
})
export class UporabnikComponent {

uporabnik:Uporabnik={ime:"",geslo:"",email:"",id:"",slik:0};
potSlik:String;
slike:Slika[];

//dinami�no ustvarjanje servisa v konstrukturju z injectorjem
constructor(private route: ActivatedRoute,private router: Router,private slikaService: SlikaService) { }

ngOnInit() {
	this.potSlik=this.slikaService.baseUrl;
    this.route.params.subscribe(params => {
       this.uporabnik.ime = params['ime'];
	   this.slikaService
      .vrni(this.uporabnik.ime)
      .subscribe(slike => this.slike = slike);

    });
  }


}
