import { Injectable } from '@angular/core';
import { Uporabnik } from './Uporabnik';
import { Http, Response,Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class UporabnikService{
private baseUrl: string = 'http://localhost:8080';
  constructor(private http : Http){
  }

  getAll(): Observable<Uporabnik[]>{
    let u = this.http
      .get(`${this.baseUrl}/uporabnik`, {headers: this.getHeaders(), withCredentials: true })
      .map(mapU);
      return u;
  }
  prijava(uporabnik:Uporabnik): Observable<Uporabnik>{
    let u = this.http
      .post(`${this.baseUrl}/uporabnik/prijava`,uporabnik, {headers: this.getHeaders(), withCredentials: true })
      .map(mapOneU);
      return u;
  }

  registracija(uporabnik: Uporabnik): Observable<any> {
    return this.http.post(`${this.baseUrl}/uporabnik`, uporabnik, {headers: this.getHeaders()})
  }

  private getHeaders(){
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    return headers;
  }
}
  function mapU(response:Response): Uporabnik[]{
   // The response of the API has a results
   // property with the actual results
   return response.json().map(toU);
}
function mapOneU(response:Response): Uporabnik{
   // The response of the API has a results
   // property with the actual results
   return response.json();
}

function toU(r:any): Uporabnik{
  let u = <Uporabnik>({
    ime: r.ime,
    email: r.email,
    geslo: r.geslo,
    slik: r.slik,
	id:r._id

  });

  return u;
}
