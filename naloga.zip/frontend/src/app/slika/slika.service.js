"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
var SlikaService = (function () {
    function SlikaService(http) {
        this.http = http;
        this.baseUrl = 'http://localhost:8080';
    }
    SlikaService.prototype.getAll = function () {
        return this.http.get(this.baseUrl + "/slika").map(mapS);
    };
    SlikaService.prototype.vrni = function (ime) {
        var baseUrl = this.baseUrl;
        var u = this.http
            .get(this.baseUrl + "/slika/" + ime, { headers: this.getHeaders(), withCredentials: true })
            .map(mapS);
        return u;
    };
    SlikaService.prototype.getOne = function (id) {
        return this.http.get(this.baseUrl + "/slika/" + id + "/podrobnosti", { headers: this.getHeaders(), withCredentials: true })
            .map(mapOneS);
    };
    SlikaService.prototype.dodaj = function (slika) {
        var formData = new FormData();
        formData.append('slika', slika.slika, slika.slika.name);
        formData.append('ime', slika.ime);
        formData.append('opis', slika.opis);
        var u = this.http.post(this.baseUrl + "/slika", formData, {
            headers: this.getHeaders(), withCredentials: true
        }).map(mapOneS);
        /*.subscribe(
            res => {
              this.responseData = res.json();
              resolve(this.responseData);
            },
            error => {
             // this.router.navigate(['/login']);
              reject(error);
            }
        );
        */
        return u;
    };
    //doda komentar
    SlikaService.prototype.dodajKomentar = function (idSlike, vsebina) {
        var body = {};
        body.vsebina = vsebina;
        return this.http.post(this.baseUrl + "/slika/" + idSlike + "/komentiraj", body, {
            headers: this.getHeaders(), withCredentials: true
        }).map(function (res) { return res.json(); });
    };
    //vseckaj (doda vsecek ali ne..vsecek?)
    SlikaService.prototype.dodajVsecek = function (idSlike, vrednost) {
        var body = {};
        body.vrednost = vrednost;
        return this.http.post(this.baseUrl + "/slika/" + idSlike + "/vseckaj", body, {
            headers: this.getHeaders(), withCredentials: true
        }).map(function (res) { return res.json(); });
    };
    SlikaService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        headers.append('Accept', 'application/json');
        return headers;
    };
    return SlikaService;
}());
SlikaService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], SlikaService);
exports.SlikaService = SlikaService;
function mapOneS(response) {
    var u = ({
        ime: response.json().ime,
        pot: response.json().pot,
        uporabnik: response.json().uporabnik,
        komentarji: response.json().komentarji,
        nalozeno: response.json().nalozeno,
        opis: response.json().opis,
        vsecki: response.json().vsecki,
        _id: response.json()._id,
        ocena: response.json().ocena,
    });
    return u;
}
function mapS(response) {
    return response.json().map(toS);
}
function toS(r) {
    var u = ({
        ime: r.ime,
        pot: r.pot,
        komentarji: r.komentarji,
        nalozeno: r.nalozeno,
        opis: r.opis,
        uporabnik: r.uporabnik,
        vsecki: r.vsecki,
        _id: r._id,
        ocena: r.ocena,
    });
    return u;
}
//# sourceMappingURL=slika.service.js.map