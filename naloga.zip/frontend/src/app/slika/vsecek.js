"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Vsecek = (function () {
    function Vsecek() {
    }
    return Vsecek;
}());
exports.Vsecek = Vsecek;
//# sourceMappingURL=vsecek.js.map