import { Component } from '@angular/core';
import { Uporabnik } from './uporabnik';
import { UporabnikService } from './uporabnik.service';

@Component({
  templateUrl:'./uporabniki.component.html',
  providers: [UporabnikService],
  styleUrls:['./uporabniki.component.css']
})
export class UporabnikiComponent {
uporabniki:Uporabnik[];
//dinami�no ustvarjanje servisa v konstrukturju z injectorjem
constructor(private uporabnikService: UporabnikService) { }

//callback dodamo ob inicializaciji
ngOnInit(){
    this.uporabnikService
      .getAll()
      .subscribe(uporabniki => this.uporabniki = uporabniki);


}
onUporabniki() {

	 this.uporabnikService
      .getAll()
      .subscribe(uporabniki => {this.uporabniki = uporabniki; console.log(uporabniki);});
  }


}
