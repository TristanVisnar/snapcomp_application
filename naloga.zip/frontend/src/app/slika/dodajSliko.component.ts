import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { Slika } from '../slika/slika';
import { SlikaService } from './slika.service';
import { Router } from '@angular/router';

@Component({
  templateUrl:'./dodajSliko.component.html',
  styleUrls:['./dodajSliko.component.css']
})
export class DodajSlikoComponent {
slika:Slika={_id:'',ime:"",slika:null,pot:"",uporabnik:"",opis:"",nalozeno:null,komentarji:[], vsecki:[], ocena: 0};
@ViewChild('slikaFile') inputSlika: ElementRef;
napaka:String;
constructor(private router: Router,private slikaService: SlikaService) { }

onDodaj(){
console.log(this.slika.ime);
		let inputSlika: HTMLInputElement = this.inputSlika.nativeElement;
		this.slika.slika=inputSlika.files[0];
		this.slikaService
		.dodaj(this.slika)
		.subscribe(slika=>this.slika=slika,error=>{console.log("Error:",error);this.napaka=JSON.parse(error._body).error;},()=>this.router.navigate(['uporabnik',this.slika.uporabnik]));
}
}
