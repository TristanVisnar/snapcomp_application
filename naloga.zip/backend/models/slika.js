//shema za objekt slika

var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;


var SlikaSchema   = new Schema({
    ime: String,
	mimetype: String,
	pot: String,
	origIme: String,
	uporabnik: String,
  opis: String,
  nalozeno: Date,
  vsecki: [{
    ime: String,
    vrednost: Number,
  }],
  ocena: Number,
  komentarji: [{
    avtor: String,
    vsebina: String,
    dodan: Date
  }]
});

module.exports = mongoose.model('Slika', SlikaSchema);
