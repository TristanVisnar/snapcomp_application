import { Component,Input } from '@angular/core';
import { Slika } from '../slika/slika';
import { SlikaService } from '../slika/slika.service';


@Component({
  selector: 'vse-slike',
  templateUrl:'./slika.vse.component.html',
  styleUrls:['./slika.vse.component.css']
})
export class VseSlikeComponent {
  public slike: Slika[];
  constructor(private slikaService: SlikaService) { }

  //callback dodamo ob inicializaciji
  ngOnInit(){
    this.slikaService.getAll().subscribe(
      response => {
        this.slike = response;
      }, error => {
        console.log("Napaka pri pridobivanju slik");
      }
    );
  }
}
