"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Uporabnik = (function () {
    function Uporabnik() {
    }
    return Uporabnik;
}());
exports.Uporabnik = Uporabnik;
//# sourceMappingURL=uporabnik.js.map