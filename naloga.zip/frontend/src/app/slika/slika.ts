export class Slika {
  _id: String;
  ime: String;
	slika: File;
	pot:String;
	uporabnik:String;
  opis:String;
  nalozeno:Date;
  komentarji:Array<any>;
  vsecki: Array<any>;
  ocena: Number;
}
