export class Vsecek {
  ime: String;
  vrednost: Number;
}
