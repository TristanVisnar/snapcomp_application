"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var uporabnik_service_1 = require("./uporabnik.service");
var router_1 = require("@angular/router");
var RegistracijaComponent = (function () {
    //dinami�no ustvarjanje servisa v konstrukturju z injectorjem
    function RegistracijaComponent(router, uporabnikService) {
        this.router = router;
        this.uporabnikService = uporabnikService;
        this.uporabnik = {
            ime: '',
            geslo: '',
            email: '',
            id: '',
            slik: 0,
        };
    }
    //callback dodamo ob inicializaciji
    RegistracijaComponent.prototype.ngOnInit = function () {
    };
    //se pokliče ob kliku na gumb registriraj
    RegistracijaComponent.prototype.onRegistracija = function () {
        var _this = this;
        this.uspeh = '';
        this.napaka = '';
        //poklici service in naredi POST na backend
        this.uporabnikService.registracija(this.uporabnik).subscribe(function (response) {
            _this.uporabnik = response; // dodaj polje ID generirano v backendu
            _this.uspeh = 'Uspešno ste se registrirali';
        }, function (error) {
            //preberi napako iz backenda
            _this.napaka = JSON.parse(error._body).error;
            //console.log(error);
        });
    };
    return RegistracijaComponent;
}());
RegistracijaComponent = __decorate([
    core_1.Component({
        selector: 'registracija',
        templateUrl: './registracija.component.html',
        providers: [uporabnik_service_1.UporabnikService],
        styleUrls: ['./registracija.component.css']
    }),
    __metadata("design:paramtypes", [router_1.Router, uporabnik_service_1.UporabnikService])
], RegistracijaComponent);
exports.RegistracijaComponent = RegistracijaComponent;
//# sourceMappingURL=registracija.component.js.map