"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Komentar = (function () {
    function Komentar() {
    }
    return Komentar;
}());
exports.Komentar = Komentar;
//# sourceMappingURL=komentar.js.map