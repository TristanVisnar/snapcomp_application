import { Component,Input, OnInit, OnDestroy } from '@angular/core';
import { Slika } from '../slika/slika';
import { SlikaService } from '../slika/slika.service';
import { Komentar } from './komentar';
import { Vsecek } from './vsecek';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'slika',
  templateUrl:'./slika.component.html',
  styleUrls:['./slika.component.css']
})
export class SlikaComponent {
  @Input() slika:Slika;
  baseUrl:String;
  napaka: String;
  komentar: Komentar={avtor:'', dodan:null, vsebina:''};
  private sub: any;
  private id: String;
  constructor(private slikaService: SlikaService, private route: ActivatedRoute) { }

  //callback dodamo ob inicializaciji
  ngOnInit(){
    this.baseUrl=this.slikaService.baseUrl;
    this.sub = this.route.params.subscribe(params => {
      this.id = params['id'];
      this.slikaService.getOne(this.id).subscribe(
        response => {
          this.slika = response;
        }, error => {
          console.log('Ni mi uspelo dobiti slike');
          //console.log(error);
        }
      )
   });
  }

  vseckaj(vrednost: Number) {
    this.napaka = '';
    this.slikaService.dodajVsecek(this.slika._id, vrednost).subscribe(
      response => {
        this.slika = response;
      }, error => {
        this.napaka = JSON.parse(error._body).error;
        //console.log(error);
      }
    )
  }

  dodajKomentar() {
    this.napaka = '';
    if (this.komentar.vsebina) {
      this.slikaService.dodajKomentar(this.slika._id, this.komentar.vsebina).subscribe(
        response => {
          this.slika = response;
        }, error => {
          this.napaka = JSON.parse(error._body).error;
          //console.log(error);
        }
      );
    } else {
      this.napaka = "Komentar ne more biti prazen";
    }
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
