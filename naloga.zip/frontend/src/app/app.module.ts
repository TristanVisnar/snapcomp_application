import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { AppComponent }  from './app.component';
import { HttpModule } from '@angular/http'; //da lahko delamo zahteve
import { UporabnikComponent } from './uporabnik/uporabnik.component';
import { UporabnikiComponent } from './uporabnik/uporabniki.component';
import { PrijavaComponent } from './uporabnik/prijava.component';
import { RegistracijaComponent } from './uporabnik/registracija.component';
import { DodajSlikoComponent } from './slika/dodajSliko.component';
import { SlikaComponent } from './slika/slika.component';
import { UporabnikService } from './uporabnik/uporabnik.service';
import { SlikaService } from './slika/slika.service';
import { RouterModule }   from '@angular/router';
import { SlikeComponent } from './slika/slike.component';
import { ReversePipe } from './slika/reverse.pipe';
import { VseSlikeComponent } from './slika/slika.vse.component';


@NgModule({
  imports:      [ BrowserModule, HttpModule, FormsModule,RouterModule.forRoot([
  {
    path: 'slika',
    component: DodajSlikoComponent
  },{
    path: 'uporabniki',
    component: UporabnikiComponent
  },{
    path: 'prijava',
    component: PrijavaComponent
  },{
    path: 'uporabnik/:ime',
    component: UporabnikComponent
  },{
    path: 'registracija',
    component: RegistracijaComponent
  }, {
    path: 'slike',
    component: VseSlikeComponent
  }, {
    path: 'slika/podrobnosti/:id',
    component: SlikaComponent,
  }
]) ],
  declarations: [ AppComponent,UporabnikiComponent,UporabnikComponent,DodajSlikoComponent,PrijavaComponent,SlikaComponent,
    RegistracijaComponent, SlikeComponent, ReversePipe, VseSlikeComponent ],
   providers: [
    UporabnikService,SlikaService
  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
