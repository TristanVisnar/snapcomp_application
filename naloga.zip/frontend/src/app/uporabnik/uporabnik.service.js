"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
var UporabnikService = (function () {
    function UporabnikService(http) {
        this.http = http;
        this.baseUrl = 'http://localhost:8080';
    }
    UporabnikService.prototype.getAll = function () {
        var u = this.http
            .get(this.baseUrl + "/uporabnik", { headers: this.getHeaders(), withCredentials: true })
            .map(mapU);
        return u;
    };
    UporabnikService.prototype.prijava = function (uporabnik) {
        var u = this.http
            .post(this.baseUrl + "/uporabnik/prijava", uporabnik, { headers: this.getHeaders(), withCredentials: true })
            .map(mapOneU);
        return u;
    };
    UporabnikService.prototype.registracija = function (uporabnik) {
        return this.http.post(this.baseUrl + "/uporabnik", uporabnik, { headers: this.getHeaders() });
    };
    UporabnikService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        headers.append('Accept', 'application/json');
        return headers;
    };
    return UporabnikService;
}());
UporabnikService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], UporabnikService);
exports.UporabnikService = UporabnikService;
function mapU(response) {
    // The response of the API has a results
    // property with the actual results
    return response.json().map(toU);
}
function mapOneU(response) {
    // The response of the API has a results
    // property with the actual results
    return response.json();
}
function toU(r) {
    var u = ({
        ime: r.ime,
        email: r.email,
        geslo: r.geslo,
        slik: r.slik,
        id: r._id
    });
    return u;
}
//# sourceMappingURL=uporabnik.service.js.map