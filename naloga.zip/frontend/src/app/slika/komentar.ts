export class Komentar {
  avtor: String;
  dodan: Date;
  vsebina: String;
}
