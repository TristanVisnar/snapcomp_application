export class Uporabnik {
    ime: String;
	geslo: String;
	email: String;
	id:String;
  slik:Number;
}
