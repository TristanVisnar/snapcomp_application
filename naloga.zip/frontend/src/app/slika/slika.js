"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Slika = (function () {
    function Slika() {
    }
    return Slika;
}());
exports.Slika = Slika;
//# sourceMappingURL=slika.js.map