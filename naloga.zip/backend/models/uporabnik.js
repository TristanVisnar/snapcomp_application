//shema za objekt uporabnik
var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var UporabnikShema   = new Schema({
    ime: String,
	geslo: String,
	email: String,
	starost: Number,
	slik: Number

});

module.exports = mongoose.model('Uporabnik', UporabnikShema);
