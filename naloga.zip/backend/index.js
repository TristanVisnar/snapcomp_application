// dodamo knjižnico express
var express    = require('express');

//dodamo parser podatkov, ki so poslani na strežnik
//ti so nato dosegljvi preko req.body v callback funkcijah zahtevi
var bodyParser = require('body-parser');


//cookie parser za razpoznavanje piškotov
var cookieParser = require('cookie-parser');

//vključimo knjižnico za delo s sejo
var session = require('express-session');

//vključimo mongoose za delo s podatkovno bazo
var mongoose=require("mongoose");

//ustvarimo aplikacijo z ogrodjem expres
var app        = express();         // naša aplikacija

//doličimo port, na katerem bo node.js zagnal strežnik
var port = process.env.PORT || 8080;

//povežemo se na mongodb bazo
//myapp je ime podatkovne zbirke, v kateri želimo imeti podatke in je lahko poljuben
mongoose.connect("mongodb://localhost:27017/myapp")
//model callbackov je nastavljen na standardni ES6 model, da se izognemo opozorilom
mongoose.Promise = global.Promise;



//app.use(function()) se vedno izvede pri vsaki zahtevi
app.use(bodyParser.json()); // knjižnica, ki nam razparsa json na vhodu
app.use(bodyParser.urlencoded({ extended: true })); // knjižnica, ki nam razparsa navadni url encoding
app.use(cookieParser()); //parsanje piškotkov
app.use(express.static('public'));
//http://expressjs-book.com/index.html%3Fp=128.html
app.use(session({secret: "MojeGeslo",saveUninitialized: true,resave: true}));
//dobimo na voljo req.session, v katerega lahko shranjujemo sejne spremenljvike

//primer funkcije, ki se izvede za vsako zahtevo
app.use(function(req,res,next){
	//pogledamo, če uporabnik, ki dela zahtevo slučajno avtenticiran/prijavljen
	var user=req.session.uporabnik;
	//console.log('Prijavljen uporabnik:' +user);


	//console.log('Zahteva iz:' +req.ip);
	//res.set('Content-Type',"UTF-8");
	next();
});

//dovolimo zahteve iz drugih domene
app.all('/*', function(req, res, next) {
//boljša logika
  res.header("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header("Access-Control-Allow-Credentials", "true");

  res.header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
  next();
});



//povemo na katerem naslovu bo naš mini app oz kontroler
var uporabnik=require('./routes/uporabnik');
app.use('/uporabnik', uporabnik);
var uporabnik=require('./routes/slika');
app.use('/slika', uporabnik);



// Začnemo poslušati
// =============================================================================
app.listen(port);
console.log('Strežnik teče na: ' + port);
