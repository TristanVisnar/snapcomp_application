"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var uporabnik_service_1 = require("./uporabnik.service");
var slika_service_1 = require("../slika/slika.service");
var router_1 = require("@angular/router");
var UporabnikComponent = (function () {
    //dinami�no ustvarjanje servisa v konstrukturju z injectorjem
    function UporabnikComponent(route, router, slikaService) {
        this.route = route;
        this.router = router;
        this.slikaService = slikaService;
        this.uporabnik = { ime: "", geslo: "", email: "", id: "", slik: 0 };
    }
    UporabnikComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.potSlik = this.slikaService.baseUrl;
        this.route.params.subscribe(function (params) {
            _this.uporabnik.ime = params['ime'];
            _this.slikaService
                .vrni(_this.uporabnik.ime)
                .subscribe(function (slike) { return _this.slike = slike; });
        });
    };
    return UporabnikComponent;
}());
UporabnikComponent = __decorate([
    core_1.Component({
        selector: 'uporabnik',
        templateUrl: './uporabnik.component.html',
        providers: [uporabnik_service_1.UporabnikService, slika_service_1.SlikaService],
        styleUrls: ['./uporabnik.component.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, slika_service_1.SlikaService])
], UporabnikComponent);
exports.UporabnikComponent = UporabnikComponent;
//# sourceMappingURL=uporabnik.component.js.map