"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var slika_1 = require("../slika/slika");
var slika_service_1 = require("../slika/slika.service");
var router_1 = require("@angular/router");
var SlikaComponent = (function () {
    function SlikaComponent(slikaService, route) {
        this.slikaService = slikaService;
        this.route = route;
        this.komentar = { avtor: '', dodan: null, vsebina: '' };
    }
    //callback dodamo ob inicializaciji
    SlikaComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.baseUrl = this.slikaService.baseUrl;
        this.sub = this.route.params.subscribe(function (params) {
            _this.id = params['id'];
            _this.slikaService.getOne(_this.id).subscribe(function (response) {
                _this.slika = response;
            }, function (error) {
                console.log('Ni mi uspelo dobiti slike');
                //console.log(error);
            });
        });
    };
    SlikaComponent.prototype.vseckaj = function (vrednost) {
        var _this = this;
        this.napaka = '';
        this.slikaService.dodajVsecek(this.slika._id, vrednost).subscribe(function (response) {
            _this.slika = response;
        }, function (error) {
            _this.napaka = JSON.parse(error._body).error;
            //console.log(error);
        });
    };
    SlikaComponent.prototype.dodajKomentar = function () {
        var _this = this;
        this.napaka = '';
        if (this.komentar.vsebina) {
            this.slikaService.dodajKomentar(this.slika._id, this.komentar.vsebina).subscribe(function (response) {
                _this.slika = response;
            }, function (error) {
                _this.napaka = JSON.parse(error._body).error;
                //console.log(error);
            });
        }
        else {
            this.napaka = "Komentar ne more biti prazen";
        }
    };
    SlikaComponent.prototype.ngOnDestroy = function () {
        this.sub.unsubscribe();
    };
    return SlikaComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", slika_1.Slika)
], SlikaComponent.prototype, "slika", void 0);
SlikaComponent = __decorate([
    core_1.Component({
        selector: 'slika',
        templateUrl: './slika.component.html',
        styleUrls: ['./slika.component.css']
    }),
    __metadata("design:paramtypes", [slika_service_1.SlikaService, router_1.ActivatedRoute])
], SlikaComponent);
exports.SlikaComponent = SlikaComponent;
//# sourceMappingURL=slika.component.js.map