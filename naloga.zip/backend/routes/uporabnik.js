var express    = require('express');
var Uporabnik=require('../models/uporabnik');
var router = express.Router();              //mini aplikacija oz del aplikacije



//dodaj uporabnika
router.post('/', function(req, res) {
	//pogledamo, če uporabnik s tem uporabniškim imenom morda že obstaja
	var q=Uporabnik.findOne({'ime':req.body.ime});
	//izvedemo poizvedbo, v primeru, da uporabnik še ne obstaja, ga dodamo
	q.exec(function(err,u) {
		if (err)
		res.send(err);
		else if(u==null){
			//ustvarimo nov objekt
			var user=new Uporabnik();
			user.ime=req.body.ime;
			user.geslo=req.body.geslo;
			user.email=req.body.email;
			user.slik=0;
			//shranimo ga v bazo
			user.save(function(err,u) {
				if (err)
				res.status(500).send({ error: err })
				else
				res.json(u); //ob uspešnem shranjevanju izpišemo celoten objekt
			});

		}
		else
		res.status(500).send({ error: "Uporabnik že obstaja!" });
	});


});

//vrni vse uporabnike
router.get('/',function(req, res) {
	//najdi vse uporabnike in jih sortiraj po imenu
	Uporabnik.find({}, null, {sort: {ime: 'asc'}}, function(err, u) {
		if (err)
		res.status(500).send({ error: err })
		else
		res.json(u); //v u imamo array vseh uporabnikov
	});
});

//vrni enega uporabnika
//req.params.ime req.params.u_id
router.get('/:u_id',function(req, res) {
	//findbyid nam vrne točno tisti objekt, ki ima predpisan id
        Uporabnik.findById(req.params.u_id, function(err, u) {
            if (err)
				res.status(500).send({ error: err })
		   else
				res.json(u);
        });
    });

//prijavi uporabnika
router.post('/prijava', function(req, res) {
	//pogledamo, če uporabnik z imenom in geslom obstaja
	var q=Uporabnik.findOne({'ime':req.body.ime,'geslo':req.body.geslo});
	//izvedemo poizvedbo
	//ob napaki lai napačni prijavi zbrišemo sejo
	//ob pravilni prijavi v sejo shranimo ime uporabnika
	q.exec(function(err,u) {
            if (err){
				req.session.destroy(function(err) {});
                res.status(500).send({ error: err })
			}
			else if(u==null){
				req.session.uporabnik="";
				req.session.destroy(function(err) {});
				res.status(500).send({ error: "Napačno geslo ali uporabnik ne obstaja!" });
			}
			else{
				req.session.uporabnik = u;
				req.session.uporabnik.geslo = 'censored';
				res.json(u);
			}
    });


});


module.exports=router;
