"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var slika_service_1 = require("./slika.service");
var router_1 = require("@angular/router");
var DodajSlikoComponent = (function () {
    function DodajSlikoComponent(router, slikaService) {
        this.router = router;
        this.slikaService = slikaService;
        this.slika = { _id: '', ime: "", slika: null, pot: "", uporabnik: "", opis: "", nalozeno: null, komentarji: [], vsecki: [], ocena: 0 };
    }
    DodajSlikoComponent.prototype.onDodaj = function () {
        var _this = this;
        console.log(this.slika.ime);
        var inputSlika = this.inputSlika.nativeElement;
        this.slika.slika = inputSlika.files[0];
        this.slikaService
            .dodaj(this.slika)
            .subscribe(function (slika) { return _this.slika = slika; }, function (error) { console.log("Error:", error); _this.napaka = JSON.parse(error._body).error; }, function () { return _this.router.navigate(['uporabnik', _this.slika.uporabnik]); });
    };
    return DodajSlikoComponent;
}());
__decorate([
    core_1.ViewChild('slikaFile'),
    __metadata("design:type", core_1.ElementRef)
], DodajSlikoComponent.prototype, "inputSlika", void 0);
DodajSlikoComponent = __decorate([
    core_1.Component({
        templateUrl: './dodajSliko.component.html',
        styleUrls: ['./dodajSliko.component.css']
    }),
    __metadata("design:paramtypes", [router_1.Router, slika_service_1.SlikaService])
], DodajSlikoComponent);
exports.DodajSlikoComponent = DodajSlikoComponent;
//# sourceMappingURL=dodajSliko.component.js.map