import { Component } from '@angular/core';
import { Uporabnik } from './uporabnik';
import { UporabnikService } from './uporabnik.service';
import { Router } from '@angular/router';
@Component({
  selector: 'prijava',
  templateUrl:'./prijava.component.html',
  providers: [UporabnikService],
  styleUrls:['./prijava.component.css']
})
export class PrijavaComponent {
napaka:String;
uporabnik:Uporabnik= {
  ime: '',
  geslo: '',
  email:'',
  id:'',
  slik:0,
};

//dinami�no ustvarjanje servisa v konstrukturju z injectorjem
constructor(private router: Router,private uporabnikService: UporabnikService) { }

//callback dodamo ob inicializaciji
ngOnInit(){



}
onPrijava() {


     this.uporabnikService
      .prijava(this.uporabnik)
      .subscribe(u=>this.uporabnik=u,error=>{console.log("Error:",error);this.napaka=JSON.parse(error._body).error;},()=>this.router.navigate(['slika']));
  }


}
