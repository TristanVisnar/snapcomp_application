import { Injectable } from '@angular/core';
import { Slika } from './slika';
import { Uporabnik } from '../uporabnik/uporabnik';
import { Http, Headers, Response} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class SlikaService{
public baseUrl: string = 'http://localhost:8080';
 requestUrl: string;
  responseData: any;
  handleError: any;
  constructor(private http : Http){
  }


  getAll(): Observable<Slika[]> {
    return this.http.get(`${this.baseUrl}/slika`).map(mapS);
  }


  vrni(ime:String): Observable<Slika[]>{
    var baseUrl=this.baseUrl;
    let u = this.http
      .get(`${this.baseUrl}/slika/${ime}`,{headers: this.getHeaders(), withCredentials: true})
      .map(mapS);
      return u;
  }

  getOne(id: String): Observable<Slika> {
    return this.http.get(`${this.baseUrl}/slika/${id}/podrobnosti`, {headers: this.getHeaders(), withCredentials: true})
                    .map(mapOneS);
  }


  dodaj(slika:Slika):Observable<Slika>{

  let formData:FormData = new FormData();
  formData.append('slika', slika.slika, slika.slika.name);
  formData.append('ime', slika.ime);
  formData.append('opis', slika.opis);

  let u=this.http.post(this.baseUrl + "/slika", formData, {
        headers: this.getHeaders(), withCredentials: true
      }).map(mapOneS);
	  /*.subscribe(
          res => {
            this.responseData = res.json();
            resolve(this.responseData);
          },
          error => {
           // this.router.navigate(['/login']);
            reject(error);
          }
      );
	  */

    return u;
  }

  //doda komentar
  dodajKomentar(idSlike: String, vsebina: String): Observable<any> {
    let body:any = {};
    body.vsebina = vsebina;
    return this.http.post(`${this.baseUrl}/slika/${idSlike}/komentiraj`, body, {
          headers: this.getHeaders(), withCredentials: true
        }).map((res: Response) => res.json());
  }

  //vseckaj (doda vsecek ali ne..vsecek?)
  dodajVsecek(idSlike: String, vrednost: Number): Observable<any> {
    let body:any = {};
    body.vrednost = vrednost;
    return this.http.post(`${this.baseUrl}/slika/${idSlike}/vseckaj`, body, {
          headers: this.getHeaders(), withCredentials: true
        }).map((res: Response) => res.json());
  }

  private getHeaders(){
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    return headers;
  }

}

function mapOneS(response:Response): Slika{
let u = <Slika>({
    ime: response.json().ime,
    pot: response.json().pot,
	  uporabnik: response.json().uporabnik,
    komentarji: response.json().komentarji,
    nalozeno: response.json().nalozeno,
    opis: response.json().opis,
    vsecki: response.json().vsecki,
    _id: response.json()._id,
    ocena: response.json().ocena,
  });
   return u;
}

function mapS(response:Response): Slika[]{
   return response.json().map(toS);
}

 function toS(r:any): Slika{
  let u = <Slika>({
    ime: r.ime,
    pot: r.pot,
    komentarji: r.komentarji,
    nalozeno: r.nalozeno,
    opis: r.opis,
    uporabnik: r.uporabnik,
    vsecki: r.vsecki,
    _id: r._id,
    ocena: r.ocena,
  });

  return u;
}
