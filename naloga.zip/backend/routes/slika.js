var express    = require('express');

//knjižnica, ki nam omogoča prejemanje datotek (multipart zahtev)
var multer = require('multer');
//mesto, kam bomo prenašali datoteke
var upload = multer({ dest: 'public/slike/' });

var router = express.Router();   //mini aplikacija za delo s slikami

//model za shranjevanje slike
var Slika=require('../models/slika');
var Uporabnik=require('../models/uporabnik');

//post zahteva na naslov najprej shrani datoteko, ki je bila na naslov posredovana z imenom slika
//ta se shrani v mapo /public/slike, na voljo pa imamo req.file, kjer so vsi podatki o sliki
//poleg same slike pričakujemo tudi lastnost ime, ki nosi podatek o naslovu (imenu) slike
router.post('/', upload.single('slika'), function(req,res){
	//če uporabnik ni prijavljen, ne more naložiti slike
	if(req.session.uporabnik==null){
		res.status(500).send({ error: "Za shranjevanje slike je potrebno biti prijavljen"})
	}
	else {
		//ustvarimo nov objekt
		var s=new Slika();

		s.ime=req.body.ime;
		s.pot='slike/'+req.file.filename;
		s.mimetype=req.file.mimetype;
		s.origIme=req.file.originalname;
		s.uporabnik=req.session.uporabnik.ime;
		s.opis = req.body.opis;
		s.nalozeno = new Date();
		s.ocena = 0;
		s.vsecki = [];
		//podatke o sliki, shranimo v podatkovno bazo
		s.save(function(err,s) {
			if (err)
				res.status(500).send({ error: err })
			else
				res.json(s);
				Uporabnik.findByIdAndUpdate(req.session.uporabnik._id, { $inc: {'slik': 1} }, function(err, u) {
					//prislo je do napake pri inkrementiranju slik uporabnika
					if (err)
						console.log(err);
				});
		});
	}
});

//zahteva vrne vse slike
router.get('/', function(req,res){
	//find vrne vse objekte, ki ustrezajo shemi Slika
	Slika.find({}, null, {sort: {nalozeno: 'desc'}}, function(err, u) {
        if (err)
            res.status(500).send({ error: err })
		else
            res.json(u);
    });
});

//zahtevamo lahko vse slike, ki jih je dodal specifični uporabnik

router.get('/:user', function(req,res){
	//v funkcijo find pošljemo del objekta kot poizvedbo
	//vsi objekti, ki ustrezajo delu objekta, so del rezultata
	Slika.find({"uporabnik":req.params.user},function(err, u) {
        if (err)
            res.status(500).send({ error: err })
		else{
			res.json(u);
		}
    });
});

//pridobi eno sliko (zaradi :user zgoraj ima na koncu se podrobnosti)
router.get('/:id/podrobnosti', function(req, res) {
	Slika.findById(req.params.id, function(err, slika) {
		if (err) {
			res.status(500).send({ error: err })
		} else {
			res.status(200).send(slika);
		}
	});
});

//zahteva za brisanje slike, preko njenega id-ja
router.delete('/:id', function(req,res){
	//preverimo če slika z idjem obstaja, in če jo je naložil uporabnik, ki je prijavljen
	Slika.findOne({"uporabnik":req.session.uporabnik,"_id":req.params.id},function(err, s) {
    if (err)
        res.status(500).send({ error: err })
	else if(!s) { //če ne, potem vrnemo napako
		res.status(500).send({ error: "Slika ne obstaja ali pa uporabnik nima ustreznih pravic"});
	}
	else{ //če ja, pa jo zbrišemo in vrnemo sporočilo ok
		//za najbolj pravilno delovanje, bi morali sliko tukaj brisati tudi z mape public/slike
		//uporabili bi lahko knjižnico fs in funkcijo unlink
		s.remove(function(err){

			if (err)
				res.status(500).send({ error: err })
			else {
				res.json({msg:"OK"});
			}
		});
	}
	});
});

//dodaj komentar h sliki preko njenega id-ja
router.post('/:id/komentiraj', function(req, res) {
	if(req.session.uporabnik==null){
		res.status(500).send({ error: "Za komentiranje slike je potrebno biti prijavljen"})
	} else {
		//posodobi komentarje slike
		//dovoli uporabniku da v nedogled vsecka
		Slika.findByIdAndUpdate(req.params.id,
			{$push: {"komentarji": {avtor: req.session.uporabnik.ime, vsebina: req.body.vsebina, dodan: new Date()}}}, {new: true}, function(err, s) {
			if (err)
				res.status(500).send({error: err});
			else if (!s)
				res.status(400).send({error: "Slike s tem id ne najdem"});
			else
				res.status(200).send(s);
		});

	}
});

router.post('/:id/vseckaj', function(req, res) {
	if(req.session.uporabnik==null){
		res.status(500).send({ error: "Za všečkanje slike je potrebno biti prijavljen"})
	} else {
		// dovoli vec vseckov na uporabnika
		/*Slika.findByIdAndUpdate(req.params.id,
		{$push: {'vsecki': {ime: req.session.uporabnik.ime, vrednost: req.body.vrednost}}, $inc: {'ocena': req.body.vrednost}}, {new: true}, function(err, s) {
			if (err)
				res.status(500).send({error: err});
			else if (!s)
				res.status(400).send({error: "Slike s tem id ne najdem"});
			else
				res.status(200).send(s);
		});*/

		//dovoli 1 vsecek ali nevsecek na uporabnika
		Slika.findById(req.params.id, function(err, slika) {
			if (err)
				res.status(500).send({error: err});
			else if (!slika)
				res.status(400).send({error: "Slike s tem id ne najdem"});
			else {
				dobiZeObstojeceOcene(req, slika, function(vsecek, kontraVrednost) {
					if (slika.vsecki.includes(vsecek[0])) {
						if (req.body.vrednost > 0) {
							res.status(400).send({error: "Sliko ste ze vseckali"});
						} else {
							res.status(400).send({error: "Sliko ste ze dislikeali"});
						}
					} else if (slika.vsecki.includes(kontraVrednost[0])) {
						var pozicija = slika.vsecki.indexOf(kontraVrednost[0]);
						slika.vsecki.splice(pozicija, 1);
						slika.vsecki.push({ime: req.session.uporabnik.ime, vrednost: req.body.vrednost});
						slika.ocena += 2*req.body.vrednost;
						slika.save(function(err, posodobljenaSlika) {
								if (err) {
									res.status(500).send({error: err});
								} else {
									res.status(200).send(posodobljenaSlika);
								}
						});
					} else {
						slika.vsecki.push({ime: req.session.uporabnik.ime, vrednost: req.body.vrednost})
						slika.ocena += req.body.vrednost;
						slika.save(function(err, posodobljenaSlika) {
								if (err) {
									res.status(500).send({error: err});
								} else {
									res.status(200).send(posodobljenaSlika);
								}
						});
					}
				});
			}
		});
	}
});

function dobiZeObstojeceOcene(req, slika, _callback) {
	var vsecek = slika.vsecki.filter(function(vsecek){ return vsecek.ime === req.session.uporabnik.ime && vsecek.vrednost === req.body.vrednost});
	var kontraVrednost = slika.vsecki.filter(function(vsecek){ return vsecek.ime === req.session.uporabnik.ime && vsecek.vrednost === -req.body.vrednost});
	_callback(vsecek, kontraVrednost);
}

module.exports=router;
