import { Component,Input } from '@angular/core';
import { Slika } from '../slika/slika';
import { SlikaService } from '../slika/slika.service';


@Component({
  selector: 'slike',
  templateUrl:'./slike.component.html',
  styleUrls:['./slike.component.css']
})
export class SlikeComponent {
  @Input() slike: Slika[];
  baseUrl:String;
  constructor(private slikaService: SlikaService) { }

  //callback dodamo ob inicializaciji
  ngOnInit(){
    this.baseUrl=this.slikaService.baseUrl;
  }
}
