"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var http_1 = require("@angular/http"); //da lahko delamo zahteve
var uporabnik_component_1 = require("./uporabnik/uporabnik.component");
var uporabniki_component_1 = require("./uporabnik/uporabniki.component");
var prijava_component_1 = require("./uporabnik/prijava.component");
var registracija_component_1 = require("./uporabnik/registracija.component");
var dodajSliko_component_1 = require("./slika/dodajSliko.component");
var slika_component_1 = require("./slika/slika.component");
var uporabnik_service_1 = require("./uporabnik/uporabnik.service");
var slika_service_1 = require("./slika/slika.service");
var router_1 = require("@angular/router");
var slike_component_1 = require("./slika/slike.component");
var reverse_pipe_1 = require("./slika/reverse.pipe");
var slika_vse_component_1 = require("./slika/slika.vse.component");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule, forms_1.FormsModule, router_1.RouterModule.forRoot([
                {
                    path: 'slika',
                    component: dodajSliko_component_1.DodajSlikoComponent
                }, {
                    path: 'uporabniki',
                    component: uporabniki_component_1.UporabnikiComponent
                }, {
                    path: 'prijava',
                    component: prijava_component_1.PrijavaComponent
                }, {
                    path: 'uporabnik/:ime',
                    component: uporabnik_component_1.UporabnikComponent
                }, {
                    path: 'registracija',
                    component: registracija_component_1.RegistracijaComponent
                }, {
                    path: 'slike',
                    component: slika_vse_component_1.VseSlikeComponent
                }, {
                    path: 'slika/podrobnosti/:id',
                    component: slika_component_1.SlikaComponent,
                }
            ])],
        declarations: [app_component_1.AppComponent, uporabniki_component_1.UporabnikiComponent, uporabnik_component_1.UporabnikComponent, dodajSliko_component_1.DodajSlikoComponent, prijava_component_1.PrijavaComponent, slika_component_1.SlikaComponent,
            registracija_component_1.RegistracijaComponent, slike_component_1.SlikeComponent, reverse_pipe_1.ReversePipe, slika_vse_component_1.VseSlikeComponent],
        providers: [
            uporabnik_service_1.UporabnikService, slika_service_1.SlikaService
        ],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map